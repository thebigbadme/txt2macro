/**
 * This code provided for non-commercial purposes only.
 * Author: thebigbadme
 * Version 1.0
 */
package txt2macro;
import java.util.Scanner;
import java.util.Arrays;

/**
 *
 * @author thebigbadme
 */
public class Txt2macro {

    /**
     * main scans user input on a loop until
     * escape char is entered (`), and systematically
     * runs each char in the input string thru
     * convertChars method.
     */
    public static void main(String[] args) {
        String userInput = "";
        String outString = "";
        char[] inputChars;
        char controlChar = ' ';
        Scanner scnr = new Scanner(System.in);
        
        while (controlChar !='`') {//allow multi-line xlation
            System.out.print("Text to translate (enter ` to terminate): ");//prompt user
            userInput = scnr.nextLine();//scan input lines
            inputChars=userInput.toCharArray();//dump input string to a char array for parsing
            
            for (int i = 0; i < inputChars.length; i++) {//walk thru chars
                if (inputChars[i] == '`') {//check for escape char
                    controlChar = '`';//flag control as needed
                }
                outString = outString.concat(convertChars(inputChars[i]));//build our output string
                if (i < inputChars.length - 1 && controlChar != '`') {//do except after last char or escape char
                    outString = outString.concat(",");//seperate chars
                }
            }
            System.out.println(outString);//print macro-fied string
            outString = "";//clear output string
        }
    }
    
    /**
     * convertChars takes char input, and returns
     * the properly format sequence to be used in
     * macro programming.
     */
    public static String convertChars(char inChar){//accepts char, spits String
        String tempString = "";
        if (Character.isLetterOrDigit(inChar)) {//in easy cases
            tempString = "+" + inChar + ",-" + inChar;//add simple formatting
            return tempString;
        }
        else if (Character.isSpaceChar(inChar)) {//space is special
            return "+space,-space";//yes, using a space requires this much text
        }
        else {//all other supported chars
            switch(inChar){//there is no good way to do this
                case '-': return "+minus,-minus";
                case '_': return "+lshift,+minus,-minus,-lshift";
                case '[': return "+lbrace,-lbrace";
                case '{': return "+lshift,+lbrace,-lbrace,-lshift";
                case ']': return "+rbrace,-rbrace";
                case '}': return "+lshift,+rbrace,-rbrace,-lshift";
                case ':': return "+lshift,+colon,-colon,-lshift";
                case ';': return "+colon,-colon";
                case '\'': return "+quote,-quote";
                case '\"': return "+lshift,+quote,-quote,-lshift";
                case '\\': return "+bslash,-bslash";
                case '|': return "+lshift,+slash,-slash,-lshift";
                case ',': return "+comma,-comma";
                case '<': return "+lshift,+commam-comma,-lshift";
                case '.': return "+dot,-dot";
                case '>': return "+lshift,+dot,-dot,-lshift";
                case '/': return "+slash,-slash";
                case '?': return "+lshift,+bslash,-bslash,-lshift";
                case '=': return "+equal,-equal";
                case '+': return "+lshift,+equal,-equal,-lshift";
                case '!': return "+lshift,+1,-1,-lshift";
                case '@': return "+lshift,+2,-2,-lshift";
                case '#': return "+lshift,+3,-3,-lshift";
                case '$': return "+lshift,+4,-4,-lshift";
                case '%': return "+lshift,+5,-5,-lshift";
                case '^': return "+lshift,+6,-6,-lshift";
                case '&': return "+lshift,+7,-7,-lshift";
                case '*': return "+lshift,+8,-8,-lshift";
                case '(': return "+lshift,+9,-9,-lshift";
                case ')': return "+lshift,+0,-0,-lshift";
            }
        }
        return tempString;//if nothing is returned, it's because the char is not supported by ckb-next
    }
    
}
